<?php 

require 'adminfunctions.php';

//Admin Class
$adminPlayer = new adminPlayer;
$adminStadistics = new adminStadistics;
$adminData = new adminData;
$adminProfile = new adminProfile;
$adminActions = new adminActions;

?>