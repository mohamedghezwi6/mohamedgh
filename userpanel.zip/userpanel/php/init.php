<?php 

require 'functions.php';

//Common Class
$player = new player;
$stadistics = new stadistics;
$admin = new admin;
$profile = new profile;
$actions = new actions;
$marketplace = new marketplace;




?>
